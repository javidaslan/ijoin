jQuery(function(){
    if(jQuery.fn.button.noConflict) {
        jQuery.fn.btn = jQuery.fn.button.noConflict();
    }
});